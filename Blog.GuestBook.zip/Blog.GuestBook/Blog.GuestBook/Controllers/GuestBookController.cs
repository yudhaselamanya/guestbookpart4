﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Blog.GuestBook.Models;

namespace Blog.GuestBook.Controllers
{
    public class GuestBookController : Controller
    {
        GuestBookReporsitory reporsitory = new GuestBookReporsitory();
        //
        // GET: /GuestBook/


        public ActionResult Index()
        {
            var model = new GuestBookEntry();
            return View(model);
        }

        [HttpPost]
        public ActionResult Index(GuestBookEntry guestBook)
        {
            reporsitory.Add(guestBook);
            reporsitory.Save();
            return RedirectToAction("ThankYou", new { id = guestBook.EntryId });
        }

        public ActionResult ThankYou(int id)
        {
            //if (TempData["entry"] == null)
            //{
            //    return RedirectToAction("index");
            //}
            //var model = (GuestBookEntry)TempData["entry"];
            //return View(model);


            GuestBookEntry entry = reporsitory.GetData(id);
            return View(entry);

        }

        public ActionResult GuestBookList()
        {
            List<GuestBookEntry> entry = reporsitory.GetAll();
            return View(entry);

        }
        //show details
        public ActionResult Details(int id)
        {
            GuestBookEntry entry = reporsitory.GetData(id);
            return View(entry);
        }

        //edit fields
        public ActionResult Edit(int id)
        {
            GuestBookEntry entry = reporsitory.GetData(id);
            return View(entry);
        }

        //POST:GuestBook/Edit
        [HttpPost]
        public ActionResult Edit(int id, FormCollection formValues)
        {
            GuestBookEntry entry = reporsitory.GetData(id);
            //entry.Name = Request.Form["Name"];
            //entry.Email = Request.Form["Email"];
            //entry.Comment = Request.Form["Comment"];

            UpdateModel(entry);

            reporsitory.Save();

            return RedirectToAction("Details", new { id = entry.EntryId });
        }

        //action delete GET :/GuestBook/Delete/1

        public ActionResult Delete(int id)
        {
            GuestBookEntry entry = reporsitory.GetData(id);
            return View(entry);
        }
        //action delete POST
        [HttpPost]
        public ActionResult Delete(int id, string confirmationButton)
        {
            GuestBookEntry entry = reporsitory.GetData(id);
            reporsitory.Delete(entry);
            reporsitory.Save();

            return View("Deleted");
        }

    }
}
