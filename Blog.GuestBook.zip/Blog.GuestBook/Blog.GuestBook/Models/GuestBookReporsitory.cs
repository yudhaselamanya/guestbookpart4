﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Blog.GuestBook.Models
{
    public class GuestBookReporsitory
    {
        private GuestBookBlogEntities entities = new GuestBookBlogEntities();
        
        public void Add(GuestBookEntry guestBook)
        {
            entities.GuestBooks.AddObject(guestBook);
        }

        public void Save()
        {
            entities.SaveChanges();
        }

        public GuestBookEntry GetData(int id)
        {
            return entities.GuestBooks.FirstOrDefault(d => d.EntryId == id);
        }

        public List<GuestBookEntry> GetAll()
        {
            return entities.GuestBooks.ToList();
        }
        //delete method
        public void Delete(GuestBookEntry entry)
        {
            entities.GuestBooks.DeleteObject(entry);
        }
    }
}