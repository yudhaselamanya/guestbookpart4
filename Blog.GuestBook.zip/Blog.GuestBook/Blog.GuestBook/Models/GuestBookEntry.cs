﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Blog.GuestBook.Models
{
    public partial class GuestBookEntry
    {
        //public int EntryId { get; set; }
        //public string Name { get; set; }
        //public string Email { get; set; }
        //public string Comments { get; set; }    
    }
}